package com.gestionderisque.gestionderisque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionderisqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionderisqueApplication.class, args);
	}

}
